<title>Ver Mascota</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<div style = 'background-color: blue;'>

<h2 style = 'color: white; text-align: center; '  > Listado mascotas</h2>

</div>

    <table class = "table table-bordered table table-striped" style = "text-align: center; ">

        <tr >
            <th>id</th></th>
            <th>Nombre</th>
            <th>Edad</th>
            <th></th>
            <td></td>
        </tr>

        <?php $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td> <?php echo $pet->id; ?>  </td>
                <td> <?php echo $pet->name; ?>  </td>
                <td> <?php echo $pet->age; ?>  </td>

                <td>
                    <a class = "btn btn-primary" href="<?php echo e(url ('/pet/' . $pet->id.'/edit' )); ?>">editar</a>
                </td>

                <td>

                <form action="<?php echo e(url ('/pet/'.$pet->id)); ?>" method = "POST">
                     <?php echo csrf_field(); ?>
                         <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Eliminar"
                                 onclick=" return confirm('Desea eliminar el registro?' ) "
                                     class = "btn btn-danger">
            </form>

                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

    <?php echo e($pets->links()); ?>


    <div class = "col-xs-12 col-sm-12 col-md-12 text-center" style = "width:1710px">
        <a class = "btn btn-success " href="<?php echo e(URL::to('pet/create/')); ?>">Crear una Mascota</a>
    </div>
<?php /**PATH C:\Users\ludwi\Downloads\Practicas Progra IV\crud_laravel_juangarcia\resources\views/pets/index.blade.php ENDPATH**/ ?>