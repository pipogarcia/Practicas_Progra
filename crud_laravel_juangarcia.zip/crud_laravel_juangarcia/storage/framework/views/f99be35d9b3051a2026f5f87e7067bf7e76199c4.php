<title>Editar Registro</title>


        <div style = "background-color: blue ">
    <h2 style = "color: white; text-align: center">Editar Mascota</h2>
    </div>

        <form action="<?php echo e(url ( '/pet/' .$pet->id )); ?>" method = "post">

            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

                <?php echo $__env->make('pets.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>

<?php /**PATH C:\Users\ludwi\Downloads\Practicas Progra IV\crud_laravel_juangarcia\resources\views/pets/edit.blade.php ENDPATH**/ ?>