<title>Crear Registro</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <div style = "background-color: blue ">
    <h2 style = "color: white; text-align: center">Ingresar una Mascota</h2>
    </div>

        <form action="<?php echo e(url ('pet')); ?>" method = "post">

            <?php echo csrf_field(); ?>
                <?php echo $__env->make('pets.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
<?php /**PATH C:\Users\ludwi\Downloads\Practicas Progra IV\crud_laravel_juangarcia\resources\views/pets/create.blade.php ENDPATH**/ ?>