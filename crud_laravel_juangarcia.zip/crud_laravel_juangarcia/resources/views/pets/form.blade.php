    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

   <div class="card">
    <div class="card-body">

        <div class = "row animate__animated animate__backInLeft">
            <div class = "col-xs-12 col-sm-12 col-md-12">
                <div class = "form-group">

                    <strong class = "align:center" >Nombre:</strong><br>
                             <input type="text" name = "name" class="form-control " id="floatingName" placeholder="Dijite su mascota"
                             value = "{{ isset($pet->name)? $pet->name: ' ' }}" >
                                <label for="name"></label>
                        </div>

                    <strong >Edad:</strong>

                            <input type="text" name = "age" class="form-control" id="floatingAge" placeholder="Dijite una Edad"
                            value = "{{ isset($pet->age)? $pet->age: ' ' }}">
                                <label for="age"></label>
                        </div>
                </div>

                      <div class = "col-xs-12 col-sm-12 col-md-12 text-center">
                        <button style =  "background-color: yellow; color: white;"  type = "submit" class = "btn" >Crear</button>
                    </div>

            </div>
        </div>
    </div>


