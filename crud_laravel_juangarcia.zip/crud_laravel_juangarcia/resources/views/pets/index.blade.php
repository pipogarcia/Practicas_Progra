<title>Ver Mascota</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<div style = 'background-color: blue;'>

<h2 style = 'color: white; text-align: center; '  > Listado mascotas</h2>

</div>

    <table class = "table table-bordered table table-striped" style = "text-align: center; ">

        <tr >
            <th>id</th></th>
            <th>Nombre</th>
            <th>Edad</th>
            <th></th>
            <td></td>
        </tr>

        @foreach ($pets as $pet)
            <tr>

                <td> {!! $pet->id !!}  </td>
                <td> {!! $pet->name !!}  </td>
                <td> {!! $pet->age !!}  </td>

                <td>
                    <a class = "btn btn-primary" href="{{ url ('/pet/' . $pet->id.'/edit' ) }}">editar</a>
                </td>

                <td>

                <form action="{{ url ('/pet/'.$pet->id) }}" method = "POST">
                     @csrf
                         {{ method_field('DELETE') }}
                            <input type="submit" value="Eliminar"
                                 onclick=" return confirm('Desea eliminar el registro?' ) "
                                     class = "btn btn-danger">
            </form>

                </td>

            </tr>
            @endforeach

    </table>

    {{ $pets->links() }}

    <div class = "col-xs-12 col-sm-12 col-md-12 text-center" style = "width:1710px">
        <a class = "btn btn-success " href="{{ URL::to('pet/create/') }}">Crear una Mascota</a>
    </div>
