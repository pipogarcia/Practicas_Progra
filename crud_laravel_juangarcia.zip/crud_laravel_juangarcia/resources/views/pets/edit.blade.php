<title>Editar Registro</title>


        <div style = "background-color: blue ">
    <h2 style = "color: white; text-align: center">Editar Mascota</h2>
    </div>

        <form action="{{ url ( '/pet/' .$pet->id ) }}" method = "post">

            @csrf
            {{method_field('PUT') }}
                @include('pets.form')

        </form>

